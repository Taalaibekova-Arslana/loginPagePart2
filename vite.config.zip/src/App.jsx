import Layout from "./components/layout/Layout";

const App = () => {
	return (
		<>
			<Layout />
		</>
	);
};

export default App;
