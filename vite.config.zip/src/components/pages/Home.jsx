// import scss from "../pages/Home.module.scss";

// import axios from "axios";
// import { useEffect } from "react";
// import { useState } from "react";
// import { useNavigate } from "react-router-dom";

// const url =
// 	"https://api.elchocrud.pro/api/v1/6e06db07a137f2ae86eadcf94b38039b/userLogin";

const Home = () => {
	// const navigate = useNavigate();
	// const [userProfile, setUserProfile] = useState([]);

	// const userId = localStorage.getItem("login");

	// const getRequest = async () => {
	// 	const response = await axios.get(url);
	// 	const responseData = response.data;

	// 	if (userId) {
	// 		const findUser = responseData.find((item) => item._id === +userId);
	// 		setUserProfile(findUser);
	// 	} else {
	// 		alert("user not found login");
	// 	}
	// };

	// useEffect(() => {
	// 	getRequest();
	// }, []);

	// const removeRequest = () => {
	// 	localStorage.removeItem("login", "1");
	// 	setUserProfile({});
	// 	navigate("/login");
	// };
	return (
		<div>
			{/* {" "}
			<div>
				<h1>{userProfile.name}</h1>
				<p>{userProfile.password}</p>
				<button onClick={removeRequest}>Exit</button>
			</div> */}
			home
		</div>
	);
};

export default Home;
