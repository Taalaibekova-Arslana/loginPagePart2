import scss from "../layout/Layout.module.scss";

import { Routes } from "react-router-dom";
import Footer from "./footer/Footer";
import Header from "./header/Header";
import { Route } from "react-router-dom";
import Home from "../pages/Home";
import Login from "../pages/Login";
import Registration from "../pages/Registration";

const Layout = () => {
	return (
		<div className={scss.Layout}>
			<Header />
			<Routes>
				<Route path="/" element={<Home />} />
				<Route path="/login" element={<Login />} />
				<Route path="/registration" element={<Registration />} />
			</Routes>
			<Footer />
		</div>
	);
};

export default Layout;
