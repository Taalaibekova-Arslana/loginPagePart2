import { useNavigate } from "react-router-dom";
import scss from "./Header.module.scss";

import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

const url =
	"https://api.elchocrud.pro/api/v1/6e06db07a137f2ae86eadcf94b38039b/userLogin";

const Header = () => {
	const navigate = useNavigate();
	const [userProfile, setUserProfile] = useState([]);
	const links = [
		{
			name: "Home",
			href: "/",
		},
		{
			name: "Login",
			href: "/login",
		},
		{
			name: "Registration",
			href: "/registration",
		},
	];
	const userId = localStorage.getItem("login");

	const getRequest = async () => {
		const response = await axios.get(url);
		const responseData = response.data;

		if (userId) {
			const findUser = responseData.find((item) => item._id === +userId);
			setUserProfile(findUser);
		} else {
			alert("user not found login");
		}
	};

	useEffect(()=>{
		getRequest()
	},[])

	const removeRequest =()=>{
		localStorage.removeItem("login", "1")
		setUserProfile({})
		navigate("/login")
	}
	return (
		<header className={scss.Header}>
			<div className="container">
				<div className={scss.content}>
					<nav>
						<ul>
							{links.map((item, index) => (
								<li key={index}>
									<Link to={item.href}>{item.name}</Link>
								</li>
							))}
						</ul>
					</nav>
				</div>
				<div>
					<h1>{userProfile.name}</h1>
					<p>{userProfile.password}</p>
					<button onClick={removeRequest}>Exit</button>
				</div>
			</div>
		</header>
	);
};

export default Header;
